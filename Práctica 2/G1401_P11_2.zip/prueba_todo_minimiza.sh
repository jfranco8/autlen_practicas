make clean
make
./prueba1
dot -Tpng afd.dot > prueba1.png

./prueba2
dot -Tpng afd.dot > prueba2.png

./prueba3
dot -Tpng afd.dot > prueba3.png

make clean
