make clean
make
./prueba2
dot -Tpng afd.dot > prueba2.png
make clean
