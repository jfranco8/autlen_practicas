make clean
make
./prueba1
dot -Tpng afd.dot > prueba1.png
make clean
