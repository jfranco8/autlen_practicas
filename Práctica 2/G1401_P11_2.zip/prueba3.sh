make clean
make
./prueba3
dot -Tpng afd.dot > prueba3.png
make clean
