make clean
make
./prueba5
dot -Tpng afd.dot > pruebas/prueba5.png
make clean
