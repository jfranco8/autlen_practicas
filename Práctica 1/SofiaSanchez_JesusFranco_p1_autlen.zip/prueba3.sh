make clean
make
./prueba3
dot -Tpng afd.dot > pruebas/prueba3.png
make clean
