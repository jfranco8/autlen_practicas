make clean
make
./prueba1
dot -Tpng afd.dot > pruebas/prueba1.png
make clean
